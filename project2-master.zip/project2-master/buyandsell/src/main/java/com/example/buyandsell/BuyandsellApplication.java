package com.example.buyandsell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuyandsellApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuyandsellApplication.class, args);
	}

}
